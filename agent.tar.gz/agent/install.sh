#!/bin/sh

pip install setuptools
pip install owlready2
pip install vk_api
pip install xes
pip install pika