#!/bin/bash

pkill python3.7
