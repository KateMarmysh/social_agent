#!/bin/sh

pkill python3.7
