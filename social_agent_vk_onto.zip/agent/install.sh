#!/bin/bash

pip install setuptools==59.6.0
pip install owlready2==0.45
pip install vk_api==11.9.9
pip install pika==1.3.2
pip install networkx==3.2.1
pip install requests==2.31.0