#!/bin/bash

pkill python3.10